#pragma once
#ifndef MONSTERMANAGER_H
#define MONSTERMANAGER_H
#include "PlayerManager.hpp"
#include <fstream>
class MonsterManager : public PlayerManager
{
private:
	static int count;
public:
	MonsterManager();
	MonsterManager(std::string _name, int _str, int _dex);
	MonsterManager(MonsterManager& monster);
	MonsterManager&::MonsterManager::operator=(const MonsterManager& _subject);
	void save_monster(MonsterManager** monster, int n);
	void load_monster(MonsterManager** monster);
	int getCount()
	{
		return count;
	}
	void print_monster();
	void make_monster(MonsterManager** player)
	{
		std::string name;
		int str, dex;
		std::cout << "�̸� : ";
		std::cin >> name;
		std::cout << "STR : ";
		std::cin >> str;
		std::cout << "DEX : ";
		std::cin >> dex;
		int sumState = str + dex;
		if (sumState > 10)
		{
			std::cout << "���!! " << name << "�� ������ ���������Դϴ�. " << std::endl;
		}
		else if (sumState < 10)
		{
			std::cout << "���!! " << name << "�� ������ ��� �й����� �ʾҽ��ϴ�. " << std::endl;
		}
		else
		{
			player[(*player)->getCount()] = new MonsterManager(name, str, dex);
		}
	}
};
#endif
