#include <iostream>
#include "Miro.h"
#include "Battle.hpp"

Miro::Miro()
{
	temp = 1;
	top = -1;
	point = 0;
}

void Miro::initScreen()
{
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			screen[i][j].status = map[i][j];
		}
	}
}

void Miro::setScreen(int _s, int _t)
{
	screen[_s][_t].status = 2;
}

void Miro::showScreen()
{
	_sleep(200);
	system("cls");
	for (auto i = 0; i < N + 2; i++)
		std::cout << "��";
	std::cout << std::endl;

	for (int i = 0; i < N; i++)
	{
		std::cout << "��";
		for (int j = 0; j < N; j++)
		{
			switch (screen[i][j].status)
			{
			case 1:
				std::cout << "��";
				break;
			case 2:
				std::cout << "��";
				break;
			case 3:
				std::cout << "xx";
				break;
			default:
				std::cout << "��";
				break;
			}
		}
		std::cout << "��";
		std::cout << std::endl;
	}

	for (auto i = 0; i < N + 2; i++)
		std::cout << "��";
	std::cout << std::endl;
}
std::string Miro::makeShortPath(MonsterManager **player)
{
	PlayerManager Mon = choose_monster(player);
	////choose_monster(player).getInfo();
	//NODE *node;
	//int s = 1, e = 1;
	//visit_screen(&screen[s][temp], s, temp);
	//showScreen();
	//while (screen[20][11].status != 2)
	//{
	//	if (screen[s][temp + 1].status != 0 && screen[s][temp + 1].visited != true)
	//	{
	//		if (screen[s][temp + 1].status == 3)
	//		{
	//			system("cls");
	//			std::cout << "��Ʋ ����!" << std::endl;
	//			_sleep(100);
	//			Battle newBattle(Mon, *player[3]);
	//			if (!(newBattle.start()))
	//				point = point + 1000;
	//			else
	//				point = point - 3000;
	//		}
	//		point = point + 500;
	//		temp++;
	//		visit_screen(&screen[s][temp], s, temp);
	//		push(&screen[s][temp]);
	//		showScreen();
	//	}
	//	else if (screen[s - 1][temp].status != 0 && screen[s - 1][temp].visited != true)
	//	{
	//		if (screen[s - 1][temp].status == 3)
	//		{
	//			system("cls");
	//			std::cout << "��Ʋ ����!" << std::endl;
	//			_sleep(100);
	//			Battle newBattle(Mon, *player[3]);
	//			if (!(newBattle.start()))
	//				point = point + 1000;
	//			else
	//				point = point - 3000;
	//		}
	//		point = point + 500;
	//		s--;
	//		visit_screen(&screen[s][temp], s, temp);
	//		push(&screen[s][temp]);
	//		showScreen();
	//	}
	//	else if (screen[s][temp - 1].status != 0 && screen[s][temp - 1].visited != true)
	//	{
	//		if (screen[s][temp - 1].status == 3)
	//		{
	//			system("cls");
	//			std::cout << "��Ʋ ����!" << std::endl;
	//			_sleep(100);
	//			Battle newBattle(Mon, *player[3]);
	//			if (!(newBattle.start()))
	//				point = point + 1000;
	//			else
	//				point = point - 3000;
	//		}
	//		point = point + 500;
	//		temp--;
	//		visit_screen(&screen[s][temp], s, temp);
	//		push(&screen[s][temp]);
	//		showScreen();
	//	}
	//	else if (screen[s + 1][temp].status != 0 && screen[s + 1][temp].visited != true)
	//	{
	//		if (screen[s + 1][temp].status == 3)
	//		{
	//			system("cls");
	//			std::cout << "��Ʋ ����!" << std::endl;
	//			_sleep(100);
	//			Battle newBattle(Mon, *player[3]);
	//			if (!(newBattle.start()))
	//				point = point + 1000;
	//			else
	//				point = point - 3000;
	//		}
	//		point = point + 500;
	//		s++;
	//		visit_screen(&screen[s][temp], s, temp);
	//		push(&screen[s][temp]);
	//		showScreen();
	//	}
	//	else
	//	{
	//		node = pop();
	//		s = node->x;
	//		temp = node->y;
	//		node->status = 1;
	//		showScreen();
	//		point = point - 300;
	//	}
	//}
	//top = -1; // �����ʱ�ȭ
	//temp = 1;
	point = point + 500;
	char a[100];
	itoa(point, a, 10);
	return Mon.getName() + ", " + a;
}
void Miro::visit_screen(NODE* screen, int s, int i)
{
	screen->x = s;
	screen->y = i;
	screen->status = 2;
	screen->visited = 1;
	screen->distance++;
	temp = i;
}

MonsterManager& Miro::choose_monster(MonsterManager **player)
{
	for (int i = 0; i < (*player)->getCount(); i++)
	{
		std::cout << i + 1 << " ";
		player[i]->getInfo();
	}
	std::cout << "�̷δ����� ���� ���͸� �����Ͻʽÿ� : ";
	int n;
	std::cin >> n;
	return *player[n - 1];
}

NODE* Miro::pop()
{
	return (stack[top--]);
}
void Miro::push(NODE *temp)
{
	stack[++top] = temp;
}
